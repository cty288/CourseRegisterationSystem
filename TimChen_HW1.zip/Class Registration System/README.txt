This is a simulation of a classs registeration system that supports administrators and students to login and manage their courses.

To run the program:
1. Use JAVA IDE (Eclipse recommended) to open this project
2. run the Main class. 
3. When first run, all initial courses are read from MyUniversityCourses.csv in the project folder.
4. Follow the instructions printed by the program, and login as an admin/student
5. When first run, there is no students in the system, so you must login as an administrator.Follow the instructions by the program, and input username and password (the username for admin is "Admin", the password is "Admin001")
6. When you successfully login into the program, the program will show the menu, input specific option number to manage your courses/ view reports/ register students. 
7. Once a task is completed, the program will return you back to the menu, so that you can start another task.
8. When finished using the program, don't forget to choose the "exit" option! So that the program will do a final save (although the program is saved each time you finish a task)
9. If it's not your first time to run the program, the program will read the .ser file when it starts. The ser file is the data saved from your last run.

 